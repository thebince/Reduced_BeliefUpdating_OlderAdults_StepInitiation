function y = tapas_rs_surprise_sim(r, infStates, p)
% Simulates RS with surprise (Ryszard Auksztulewicz)
%
% --------------------------------------------------------------------------------------------------
% Copyright (C) 2016 Christoph Mathys, TNU, UZH & ETHZ
%
% This file is part of the HGF toolbox, which is released under the terms of the GNU General Public
% Licence (GPL), version 3. You can redistribute it and/or modify it under the terms of the GPL
% (either version 3 or, at your option, any later version). For further details, see the file
% COPYING or <http://www.gnu.org/licenses/>.

p = exp(p);

% Get parameters
ze1v = p(1);
ze1i = p(2);
ze2  = p(3);
ze3  = p(4);

% Inputs
u = r.u(:,1);
mu1hat = infStates(:,1,1);
mu1hat(r.ign) = [];

% Calculate alpha (i.e., attention)
alpha = 1./(1-log2(mu1hat));

% Calculate predicted response speed
y = u.*(ze1v + ze2*alpha) + (1-u).*(ze1i + ze2*(1-alpha));

end
