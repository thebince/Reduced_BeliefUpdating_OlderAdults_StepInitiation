function tapas_print_logo()
%% Print the logo of tapas.

%
% aponteeduardo@gmail.com
% copyright (C) 2017
%

disp( '_______            _____                _____       _____           ____                ');
disp( '   |              |     |              |_____|     |     |         |                    ');
disp( '   |              |-----|              |           |-----|          ----|               ');
disp(['   | RANSLATIONAL |     |LGORITHMS FOR |SYCHIATRY  |     |DVANCING  ____|CIENCE         ','']);
fprintf('\n');

end
